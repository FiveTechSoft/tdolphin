/*
 * $Id: hbpp.c 14973 2010-07-02 12:21:18Z druzus $
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008-2010 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#define HB_VER_SVNID             15137

#define HB_VER_CHLID             "ChangeLog 15137 2010-07-17 13:05:21Z vszakats"

#define HB_VER_LENTRY            "2010-07-17 14:59 UTC+0200 Viktor Szakats (harbour.01 syenar.hu)"

#define HB_PLATFORM              "win"

#define HB_COMPILER              "bcc"

LOAD DATA LOCAL INFILE "student.txt" INTO TABLE student;

This directory contains a table definition and some sample data to
use for FULLTEXT searching. You can use them to try the examples in
the FULLTEXT section of Chapter 2.

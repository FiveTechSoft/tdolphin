/*
  This file is for use with builders' local defines
  Never ever upload a modified version of this file to CVS as it may not
  work for others
*/

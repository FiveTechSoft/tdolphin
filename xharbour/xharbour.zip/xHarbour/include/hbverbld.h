/*
 * $Id: ppgen.c,v 1.18 2010/01/01 03:14:40 andijahja Exp $
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://www.harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#ifndef __HBVERBLD_INCLUDED
#define __HBVERBLD_INCLUDED

#define HB_VER_CVSID	6719

#if defined(HB_VER_CHLCVS)
#undef HB_VER_CHLCVS
#endif

#define HB_VER_CHLCVS	"ChangeLog,v 1.6719 2010/06/18 22:21:47 ronpinkas Exp"

#if defined(HB_VER_LENTRY)
#undef HB_VER_LENTRY
#endif

#define HB_VER_LENTRY	"2010-06-18 17:48 UTC-0430 Ron Pinkas <ron.pinkas/at/xharbour.com>"

#endif /* __HBVERBLD_INCLUDED */
